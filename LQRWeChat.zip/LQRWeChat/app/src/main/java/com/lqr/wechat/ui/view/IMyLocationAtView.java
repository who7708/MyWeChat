package com.lqr.wechat.ui.view;


import com.lqr.recyclerview.LQRRecyclerView;

public interface IMyLocationAtView {
    LQRRecyclerView getRvPOI();
}

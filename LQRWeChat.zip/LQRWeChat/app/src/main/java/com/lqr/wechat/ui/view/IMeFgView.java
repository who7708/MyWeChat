package com.lqr.wechat.ui.view;


import android.widget.ImageView;
import android.widget.TextView;

public interface IMeFgView {
    ImageView getIvHeader();

    TextView getTvName();

    TextView getTvAccount();
}

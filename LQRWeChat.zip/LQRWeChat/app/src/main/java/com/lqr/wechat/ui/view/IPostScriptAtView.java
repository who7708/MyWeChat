package com.lqr.wechat.ui.view;

import android.widget.EditText;

public interface IPostScriptAtView {
    EditText getEtMsg();
}

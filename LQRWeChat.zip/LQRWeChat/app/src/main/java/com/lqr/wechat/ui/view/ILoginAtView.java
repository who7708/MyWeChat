package com.lqr.wechat.ui.view;

import android.widget.EditText;

/**
 * @创建者 CSDN_LQR
 * @描述 登录界面的View
 */
public interface ILoginAtView {

    EditText getEtPhone();

    EditText getEtPwd();
}

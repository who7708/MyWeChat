package com.lqr.wechat.ui.view;

import android.widget.ImageView;

import com.lqr.optionitemview.OptionItemView;

public interface IMyInfoAtView {
    ImageView getIvHeader();

    OptionItemView getOivName();

    OptionItemView getOivAccount();
}

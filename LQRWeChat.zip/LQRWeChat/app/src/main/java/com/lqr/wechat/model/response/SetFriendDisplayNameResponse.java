package com.lqr.wechat.model.response;

/**
 * Created by AMing on 16/2/17.
 * Company RongCloud
 */
public class SetFriendDisplayNameResponse {

    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}

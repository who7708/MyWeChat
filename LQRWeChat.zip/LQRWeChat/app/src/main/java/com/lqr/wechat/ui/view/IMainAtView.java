package com.lqr.wechat.ui.view;


import android.widget.TextView;

public interface IMainAtView {

    TextView getTvMessageCount();

}

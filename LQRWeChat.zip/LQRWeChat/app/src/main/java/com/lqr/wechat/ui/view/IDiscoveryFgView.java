package com.lqr.wechat.ui.view;


public interface IDiscoveryFgView {
}

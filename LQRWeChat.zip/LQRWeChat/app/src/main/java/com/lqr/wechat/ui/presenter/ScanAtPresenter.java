package com.lqr.wechat.ui.presenter;

import com.lqr.wechat.ui.base.BaseActivity;
import com.lqr.wechat.ui.base.BasePresenter;
import com.lqr.wechat.ui.view.IScanAtView;


public class ScanAtPresenter extends BasePresenter<IScanAtView> {

    public ScanAtPresenter(BaseActivity context) {
        super(context);
    }
}

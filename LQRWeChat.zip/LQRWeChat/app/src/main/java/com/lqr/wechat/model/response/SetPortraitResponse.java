package com.lqr.wechat.model.response;

/**
 * Created by AMing on 16/1/13.
 * Company RongCloud
 */
public class SetPortraitResponse {

    /**
     * code : 200
     */

    private int code;

    public void setCode(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

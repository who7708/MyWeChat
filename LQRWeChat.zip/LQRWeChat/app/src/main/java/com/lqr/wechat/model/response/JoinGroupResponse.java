package com.lqr.wechat.model.response;

/**
 * Created by AMing on 16/4/1.
 * Company RongCloud
 */
public class JoinGroupResponse {
    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}

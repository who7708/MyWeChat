package com.lqr.wechat.ui.presenter;

import com.lqr.wechat.ui.base.BaseActivity;
import com.lqr.wechat.ui.base.BasePresenter;
import com.lqr.wechat.ui.view.IAddFriendAtView;


public class AddFriendAtPresenter extends BasePresenter<IAddFriendAtView> {

    public AddFriendAtPresenter(BaseActivity context) {
        super(context);
    }
}

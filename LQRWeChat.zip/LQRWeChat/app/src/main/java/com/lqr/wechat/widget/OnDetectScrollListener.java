package com.lqr.wechat.widget;

public interface OnDetectScrollListener {

        public void onUpScrolling();

        public void onDownScrolling();
    }
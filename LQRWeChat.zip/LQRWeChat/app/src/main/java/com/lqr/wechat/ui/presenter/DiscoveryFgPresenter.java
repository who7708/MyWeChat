package com.lqr.wechat.ui.presenter;

import com.lqr.wechat.ui.base.BaseActivity;
import com.lqr.wechat.ui.base.BasePresenter;
import com.lqr.wechat.ui.view.IDiscoveryFgView;

public class DiscoveryFgPresenter extends BasePresenter<IDiscoveryFgView> {

    public DiscoveryFgPresenter(BaseActivity context) {
        super(context);
    }
}

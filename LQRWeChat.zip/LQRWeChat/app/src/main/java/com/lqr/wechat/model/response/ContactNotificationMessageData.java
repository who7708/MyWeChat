package com.lqr.wechat.model.response;

/**
 * Created by AMing on 16/2/24.
 * Company RongCloud
 */
public class ContactNotificationMessageData {
    /**
     * sourceUserNickname : 赵哈哈
     * version : 1456282826213
     */

    private String sourceUserNickname;
    private long version;

    public void setSourceUserNickname(String sourceUserNickname) {
        this.sourceUserNickname = sourceUserNickname;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public String getSourceUserNickname() {
        return sourceUserNickname;
    }

    public long getVersion() {
        return version;
    }

    /**
     * sourceUserNickname : asdf
     * version : 1212121212
     */
//
//    private String sourceUserNickname;
//    private String version;
//
//    public ContactNotificationMessageData(String sourceUserNickname, String version) {
//        this.sourceUserNickname = sourceUserNickname;
//        this.version = version;
//    }
//
//    public void setSourceUserNickname(String sourceUserNickname) {
//        this.sourceUserNickname = sourceUserNickname;
//    }
//
//    public void setVersion(String version) {
//        this.version = version;
//    }
//
//    public String getSourceUserNickname() {
//        return sourceUserNickname;
//    }
//
//    public String getVersion() {
//        return version;
//    }


}
